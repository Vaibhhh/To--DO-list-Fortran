This application reads from a file (or creates a new file if not found) a To Do List.
Displays the list to console.
User have the ability to add new things to do and remove exisiting things.
Once done, the program will write contents to a file and save it.

Max number of tasks: 100.

This program was written in Fortran (.f90)

Source code in LinkedInLearning_FortranIntro_ToDo_Project --> ToDoProject.f90
